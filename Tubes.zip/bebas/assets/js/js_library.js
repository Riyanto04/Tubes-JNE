/*===============================================================================================================   
Company     : PT Web Architect Technology - webarq.com 
Author      : Andri Samsuri
Built       : Desember 2015
=============================================================================================================== */


/* element onscreen detect
 =============================================================================================================== */
$.fn.isOnScreen = function () {
    if (this.length) {
        var viewport = {};
        viewport.top = $(window).scrollTop();
        viewport.bottom = viewport.top + $(window).height();
        var bounds = {};
        bounds.top = this.offset().top;
        bounds.bottom = bounds.top + this.outerHeight();
        return ((bounds.top <= viewport.bottom) && (bounds.bottom >= viewport.top));
    } else
        return false;
};

/* function for scroll content
 =============================================================================================================== */
$.fn.scrollAnim = function () {
    var actAnimfunction = function (elem, elem_position, delay) {
        if (elem_position === "top") {
            TweenLite.to(elem, 0.5, {
                css: {
                    'opacity': '1',
                    'margin-top': '0px'
                },
                delay: delay,
                ease: Quart.easeOut
            });
        } else if (elem_position === "bottom") {
            TweenLite.to(elem, 0.5, {
                css: {
                    'opacity': '1',
                    'margin-bottom': '0px'
                },
                delay: delay,
                ease: Quart.easeOut
            });
        } else if (elem_position === "left") {
            TweenLite.to(elem, 0.5, {
                css: {
                    'opacity': '1',
                    'margin-left': '0px'
                },
                delay: delay,
                ease: Quart.easeOut
            });
        } else if (elem_position === "right") {
            TweenLite.to(elem, 0.5, {
                css: {
                    'opacity': '1',
                    'margin-right': '0px'
                },
                delay: delay,
                ease: Quart.easeOut
            });
        } else if (elem_position === "absolute_bottom") {
            TweenLite.to(elem, 0.5, {
                css: {
                    'opacity': '1',
                    'bottom': '0px'
                },
                delay: delay,
                ease: Quart.easeOut
            });
        } else if (elem_position === "absolute_right") {
            TweenLite.to(elem, 0.5, {
                css: {
                    'opacity': '1',
                    'right': '0px'
                },
                delay: delay,
                ease: Quart.easeOut
            });
        } else if (elem_position === "absolute_left") {
            TweenLite.to(elem, 0.5, {
                css: {
                    'opacity': '1',
                    'left': '0px'
                },
                delay: delay,
                ease: Quart.easeOut
            });
        } else if (elem_position === "absolute_top") {
            TweenLite.to(elem, 0.5, {
                css: {
                    'opacity': '1',
                    'top': '0px'
                },
                delay: delay,
                ease: Quart.easeOut
            });
        } else if (elem_position === "fade") {
            TweenLite.to(elem, 0.5, {
                css: {
                    'opacity': '1',
                    'scale': '1'
                },
                delay: delay,
                ease: Quart.easeOut
            });
        } else {
            TweenLite.to(elem, 0.5, {
                css: {
                    'opacity': '1',
                    'scale': '1'
                },
                delay: delay,
                ease: Quart.easeOut
            });
        }
    };
    var elem = this;
    $(window).scroll(function () {
        elem.each(function () {
            var elem_ = $(this);
            if (elem_.isOnScreen()) {
                var delay = parseFloat(elem_.attr('anim-delay'));
                //console.log(delay);
                actAnimfunction(elem_, elem_.attr('type-anim'), delay);
            }

        });
    });
};

/* function input file
 =============================================================================================================== */
$.fn.fileInputC = function (e) {
    var elem = this, input = elem.find("input");

    input.on('change', function () {
        value = $(this).val();
        if (value != "") {
            value = value.substring(12, value.length);
            $(this).next("span").html(value);
        } else {
            $(this).next("span").html(elem.attr('placeholder-text'));
        }
    });
}

function openPop(selector) {
    $(selector).fadeIn(300);
}
function closePop(selector) {
    $(selector).fadeOut(300);
}



$.fn.generate_height = function () {
    var maxHeight = -1;
    $(this).each(function () {
        $(this).children().each(function () {
            maxHeight = maxHeight > $(this).height() ? maxHeight : $(this).height();
        });

        $(this).children().each(function () {
            $(this).height(maxHeight);
        });
    })

}