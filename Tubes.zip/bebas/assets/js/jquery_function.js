/*===============================================================================================================	
CSS Decorated By    : Web Architect (webarq.com)
Author              : DebfryAp              
================================================================================================================= */
$(document).ready(function () {
	$("select").each(function (index, element) {
		var width = $(this).outerWidth();
		var $this = $(this);		
		if($(this).hasClass("required"))
		{
			var value = $this.children('option:first').text()+"<strong>*</strong>";
		}
		else
		{
			var value = $(this).children('option:first').text();
		}
		
		$(this).wrap("<div class=selector_form>");
		$(".selector_form").eq(index).css('width', width + 'px').prepend("<span>" + value + "</span>");
		$(this).on('change', function () {
			var value = $(this).children(":selected").text();
			if (value.length >= 20) {
				$(this).siblings("span").text(value.substring(0, 20) + "..");
			} else {
				$(this).siblings("span").text(value);
			}
		});
	});
	$.fn.set_label = function(){
		var char_ = $(this).children().text();
		var text = char_.substring(0,1);
		$(this).prepend("<div class='label'>"+text+"</div>");		
	}
	$(".set-label").set_label();
	$.fn.backTop = function(){
		if(!$(this).hasClass("no-topnav"))
		{
			$(this).append("<div class='topnav'></div>");			
		}
		$(".topnav").click(function(){
			$("html, body").animate({scrollTop: 0}, 500);
		});
	}	
	$(".main-content").backTop();
	$.fn.timeline = function(){
		var content = $(this).find('.content');
		var cur = $(this).find(".slide");

		cur.first().addClass("active");
		content.children(".items").first().show();

		cur.click(function(){
			cur.removeClass("active");
			$(this).addClass("active");
			var id = $(this).text();
			content.children(".items").hide();			
			$("#"+id).show();
		});
	}
	$("#menu_mobile ul li.hasChild > a").click(function(){
		$(this).siblings('ul').slideToggle(300);
		return false;
	})
	$("#timeline").timeline();
    function menu_mobile(){
		var trigger = $("#nav_mobile .fly-but-wrap");
		var width = 250;
		trigger.click(function(){
			$(this).toggleClass('fly-open');
			$("header").toggleClass('slide')
			if($("header").hasClass('slide'))
			{
				TweenMax.to([$("header"),$("footer"),$('#container')],0.5,{
					'marginLeft' : -width,
					'marginRight' : width,
				});	
				TweenMax.to($("#menu_mobile"),0.5,{
					marginRight : 0,
				});
				$('body').css('overflow','hidden');
			}
			else
			{
				TweenMax.to([$("header"),$("footer"),$('#container')],0.5,{
					'marginLeft' : 0,
					'marginRight' : 0,
					onComplete : function(){
						$("body,header,footer,#container").removeAttr("style");
					}
				});
				TweenMax.to($("#menu_mobile"),0.5,{
					marginRight : -width,
				})
			}
			
			return false;
		})
	}
	menu_mobile();
	//repostionImageBanner(); 
	
		$(".input_file").fileInputC();
        
        
        //scroll anim homepage
        $('.home #widget .cols').scrollAnim();
        $('.home #promo h4.line_top').scrollAnim(); 
        $('.home #promo .list-promo .items').scrollAnim(); 
        $('.home #recognition').scrollAnim(); 
        
        $('.home footer .top .left').scrollAnim(); 
        $('.home footer .top .right nav').scrollAnim(); 
        $('.home footer .top .right .sos_mobile').scrollAnim(); 
        $('.home footer .bottom .left').scrollAnim(); 
        $('.home footer .bottom .phone').scrollAnim();
        $("#popup_jne").delay(2000).fadeIn();

        $(".list-news").generate_height();
	
});