<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lokasi extends CI_Model{
    
    public function get_all(){
        $data = $this->db->query("SELECT * FROM tb_lokasi");
        return $data->result_array();
    }

    public function add_lokasi($data){
        $this->db->query("INSERT INTO tb_lokasi VALUES(NULL,'".$data['id_lokasi']."','".$data['nama_jne']."',".$data['alamat_jne']."')");
    }

    public function delete_lokasi($id){
        $this->db->query("DELETE FROM tb_lokasi WHERE id_lokasi = '".$id."'");
    }

    public function updatelokasi($data){
        $this->db->query("UPDATE tb_lokasi SET id_lokasi = '".$data['id_lokasi']."',nama_jne = '".$data['nama_jne']."' ,alamat_jne = '".$data['alamat_jne']."' ");
    }
}