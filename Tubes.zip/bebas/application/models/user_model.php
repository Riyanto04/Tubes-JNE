<?php
class User_Model extends CI_Model
{
		public function verivikasi_login() {
		$username = $this->input->POST('username', TRUE);
		$password = md5($this->input->POST('password', TRUE));
		$query = $this->db->query("SELECT * from user where username= '$username' and password= '$password' LIMIT 1");
		if($query->num_rows() == 0){
			return false;
		}else{
			$data = $query->row();
			$_SESSION['login'] = array('id_user'=>$data->id_user,'username'=>$data->username,"password"=>$data->password,'level'=>$data->level);
			return true;
		}
	}
}