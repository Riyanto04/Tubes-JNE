<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login extends CI_Controller {
	public function __construct()
 	{
 		date_default_timezone_set('Asia/Jakarta');
 		parent::__construct();
 		$this->load->model('user_model');
 		$this->load->database();
 		$this->load->helper('url');
  	}
	
	public function index()
	{
		$data['title'] = "Login";
		$this->load->view('login',$data);
	}
	public function auth()
 	{
 		if($this->user_model->verivikasi_login()){
 			redirect('admin');
      }else{
                  $this->session->set_flashdata("pesan", "<div class=\"col-lg-4 col-lg-offset-4\"><div class=\"alert alert-danger\">
    <a  class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a>
        <strong>Oops!</strong><br> Username/password yang Anda Masukan Salah<br><b>Atau Akun Belum Terdaftar !</b>
      </div></div>");
            redirect('login');
        }
 	}
	
	public function logout()
 	{
 		session_destroy();
 		redirect('login');	
 	}
	
}
