<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('lokasi');
    }
    public function index()
    {
        
        $data = array();
        $data['listlokasi'] = $this->lokasi->get_all();
        $this->load->view('mebel_view',$data);
    }
    public function addlokasi(){
        $data=array(
            'id_lokasi'=>$this->input->post('id_lokasi'),
            'nama_jne'=>$this->input->post('nama_jne'),
            'alamat_jne'=>$this->input->post('alamat_jne'),
        );
        $this->lokasi->add_lokasi($data);
        redirect('home');
    }

    public function deletelokasi($id_lokasi){
        $this->lokasi->delete_lokasi($id_lokasi);
        redirect('home');
    }

    public function editform($id_lokasi){
        $data=array();
        $data['datalokasi'] = $this->lokasi->get_data($id_lokasi);
        $this->load->view('formedit',$data);
    }

    public function update(){
        $data=array(
            'id_lokasi'=>$this->input->post('id_lokasi'),
            'nama_jne'=>$this->input->post('nama_jne'),
            'alamat_jne'=>$this->input->post('alamat_jne'),
        );
        $this->lokasi->updatelokasi($data);
        redirect('home');
    }

    public function fcreate(){
        $this->load->view('fcreate');
    }
}
