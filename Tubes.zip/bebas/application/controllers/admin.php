<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {
		public function __construct()
 	{
 		date_default_timezone_set('Asia/Jakarta');
 		parent::__construct();
 		$this->load->database();
 		$this->load->helper('url');
  	}

	public function index()
	{
		$this->load->view('dashboard');
	}

	public function career()
	{
		$this->load->view('career');
	}

	public function input_tracking(){
		$data = array(
		"nm_pengirim" => $_POST['nm_pengirim'],
		"kode_tracking" => $_POST['kode_tracking'],
		"alamat_tujuan" => $_POST['alamat_tujuan'],
		"nm_penerima" => $_POST['nm_penerima']
		);

		$inputtr = $this->db->insert('tb_tracking',$data);

		if ($inputtr >= 1) {
		redirect('admin');
		}else{
			redirect('admin');
		}
	}


	public function input_career(){
		$data = array(
		"jd_career" => $_POST['jd_career'],
		"deskripsi" => $_POST['deskripsi']
		);

		$inputcr = $this->db->insert('tb_career',$data);

		if ($inputcr >= 1) {
		redirect('career');
		}else{
			redirect('career');
		}

	

	}
}
