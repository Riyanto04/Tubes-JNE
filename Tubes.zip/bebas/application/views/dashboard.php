<!DOCTYPE html>
<html>
<head>
	<title>Dashboard </title>
</head>
<body>
	<form action="<?= base_url()?>index.php/admin/input_tracking" method="POST">
		<center>
		<h2>Tracking Barang</h2>
		<br><input type="text" name="nm_pengirim" placeholder="Nama Pengirim"></br>
		<br><input type="text" name="kode_tracking" placeholder="Kode"></br>
		<br><input type="text" name="alamat_tujuan" placeholder="Alamat"></br>
		<br><input type="text" name="nm_penerima" placeholder="Penerima"></br>
		<br><input type="submit" name="submit"></br>
		</center>
	</form>
</body>
</html>