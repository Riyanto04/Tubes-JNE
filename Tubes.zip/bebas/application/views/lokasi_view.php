<html>
<head>
<style>
    table,tr,td{
        border : 1px solid;
        border-colapse:colapse;
    }
</style>
 <link rel="stylesheet" href="<?php echo base_url('assets/template/bootstrap/css/bootstrap.min.css')?>">
    <script src="<?php echo base_url('assets/template/plugins/jQuery/jQuery-2.1.4.min.js')?>"></script>
    <script src="<?php echo base_url('assets/template/bootstrap/js/bootstrap.min.js')?>"></script>
</head>
<body>

    <div class="container mt-5">
        <h2>Data Lokasi</h2>
        <div class="row">
            <div class="col-md-12">
            
                <div align="right" style="margin-right: 4%;margin-bottom: 2%">
                    <button class="btn btn-sm btn-primary action" onclick="location.href='<?php echo site_url('home/fcreate'); ?>'">Create</button>
                </div>
                <table class="table">
                    <tr>
                        <td>ID Lokasi</td>
                        <td>Nama Lokasi JNE</td>
                        <td>Alamat JNE</td>
                    </tr>
                    <?php
                    foreach ($listlokasi as $a){
                    ?>
                    <tr>
                        <td><?php echo $a['id_lokasi']; ?></td>
                        <td><?php echo $a['nama_jne']; ?></td>
                        <td><?php echo $a['lokasi_jne']; ?></td>
                        <td>
                            <button class="btn btn-sm btn-danger action" data-toggle="modal" data-target="#modal-delete<?php echo $a['id_mebel']; ?>">delete</button>
                            <?php include "fdelete.php"; ?>
                            <button class="btn-sm btn btn-primary action" data-toggle="modal" data-target="#modal-update<?php echo $a['id_mebel']; ?>">edit</button>
                            <?php include "fedit.php"; ?>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
        
            </div>

    </div>
</div>
</body>
</html>
