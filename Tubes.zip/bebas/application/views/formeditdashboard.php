     <div class="form-group">
            <form action="<?= base_url()?>index.php/admin/input_tracking" method="POST" enctype="multipart/form-data">

            <div class="form-group">
                <label for="nm_pengirim">Nama Pengirim</label>
                <input class="form-control" type="text" name="nm_pengirim" value="<?php echo $a['nm_pengirim'];?>" placeholder="Nama Pengirim" required/>
            </div>
 
            <div class="form-group">
                <label for="kode_tracking">kode tracking</label>
                <input class="form-control" type="text" name="kode_tracking" value="<?php echo $a['kode_tracking'];?>" readonly/>
            </div>

            <div class="form-group">
                <label for="alamat_tujuan">Alamat Tujuan</label>
                <input class="form-control" type="text" name="alamat_tujuan" value="<?php echo $a['alamat_tujuan'];?>" placeholder="Kategori" required/>
            </div>

            <div class="form-group">
                <label for="nm_penerima">Nama Penerima</label>
                <input class="form-control" type="number" name="nm_penerima" value="<?php echo $a['nm_penerima'];?>" placeholder="Nama Penerima" required/>
            </div>

                <input type="submit" class="btn btn-primary btn-block" name="update" value="update" />

        </form>
      </div>