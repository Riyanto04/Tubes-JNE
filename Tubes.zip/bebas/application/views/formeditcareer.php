     <div class="form-group">
            <form action="<?= base_url()?>index.php/admin/input_tracking" method="POST" enctype="multipart/form-data">

            <div class="form-group">
                <label for="id_career">Karir</label>
                <input class="form-control" type="text" name="id_career" value="<?php echo $a['id_career'];?>" placeholder="Karir" required/>
            </div>
 
            <div class="form-group">
                <label for="jd_career">judul karir</label>
                <input class="form-control" type="text" name="jd_career" value="<?php echo $a['jd_career'];?>" readonly/>
            </div>

            <div class="form-group">
                <label for="deskripsi">Deskripsi</label>
                <input class="form-control" type="text" name="deskripsi" value="<?php echo $a['deskripsi'];?>" placeholder="Kategori" required/>
            </div>
                <input type="submit" class="btn btn-primary btn-block" name="update" value="update" />

        </form>
      </div>