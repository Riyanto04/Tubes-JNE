
<!DOCTYPE html>
<html class="no-js">
<head>
    <meta charset="utf-8">
    <title>JNE Express</title>
    <!--Style-->
    <link rel="stylesheet" href="<?= base_url()?>assets/web/css/reset.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>assets/web/css/camera.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>assets/web/css/jquery-ui.css">
    <link rel="stylesheet" href="<?= base_url()?>assets/web/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url()?>assets/web/css/sweetalert.css"> 
    <!--js-->
    <script>window.jQuery || document.write('<script src="<?= base_url()?>assets/web/js/jquery-1.9.1.min.js"><\/script>')</script>
    <script src="<?= base_url()?>assets/web/js/modernizr-2.6.2.min.js"></script>
    <script src="<?= base_url()?>assets/web/js/TweenMax.min.js"></script>
    <script src="<?= base_url()?>assets/web/js/jquery.bxslider.js"></script>
    <script src="<?= base_url()?>assets/web/js/js_library.js"></script>
    <script src="<?= base_url()?>assets/web/js/jquery_function.js"></script>
    <script src="<?= base_url()?>assets/web/js/sweetalert.min.js"></script>
  
<body class="home">

<!-- header -->
<header>
	<div class="wrapper afterclear">          
	<div class="logo"><a href="#"><img src="<?= base_url()?>assets/web/img/logo.jpg"></a></div>

<!--   bagain navigation bar -->
		<nav>
			<ul>
                    <li>    
                         <a class = '' href="#" >Perusahaan</a>
                    </li>

<!--  CRUD 3  --> 
                    <li>    
                         <a class = '' href="#" >Produk &amp; Layanan</a>
                    </li>

                    <li>    
                        <a class = '' href="#" >Solusi Bisnis</a>
                    </li>

                    <li>    
 <!-- CRUD 2 -->         <a class = '' href="#" >Karir</a>

                    </li>

                    <li>    
                          <a class = '' href="#" >Hubungi Kami</a>
                    </li>
			</ul>			
    </nav>
	</div>
</header>


<div id="container">


<!-- middle -->
<section> 
  <div class="camera_wrap camera_magenta_skin" id="camera_wrap_2">
      
<!--  slide gambar   -->        
      <div data-src="<?= base_url()?>assets/web/img/slider-337.jpg" data-link = "" data-target="_blank"> 
      </div>

          
      <div data-src="<?= base_url()?>assets/web/img/slider-351.jpg" data-link = "" data-target="_blank"> 
      </div>

          
      <div data-src="<?= base_url()?>assets/web/img/slider-352.jpg" data-link = "" data-target="_blank"> 
      </div>

          
      <div data-src="<?= base_url()?>assets/web/img/slider-357.jpg" data-link = "" data-target="_blank"> 
      </div>

  </div>
</section>


<section id="tracking">
  <link rel='stylesheet' type='text/css' href='#'>
  <script type="text/javascript">
    var CaptchaCallback = function(){
    };
  </script>

  <link rel='stylesheet' type='text/css' href='#'>
  <div class="wrapper afterclear">
    
  <form class="trace validate drop-captcha" id = 'traceForm' action="#" method='post' name = 'form-trace'>

    <input type="hidden" name="_token" value="#">
<!-- CRUD 1 -->
      <h3><strong></strong><b>LACAK KIRIMAN</b></h3>
      <div class="row" style="position:relative;">
          <textarea name='code' class='required'></textarea>
              <div id="#">
               <assets/web/img style="float: left; padding-right: 5px"/><div id="#">
              </div>
            </div>
          <button class="btn green" name = 'tracking' type="submit">tracking</button>
      </div>
    </form>
<!-- akhir dari lacak pengiriman   -->

<!-- awal dari tarif pengiriman -->
    <form class="check validate drop-captcha" action='#' method='post' name = 'form-check'>
      <input type="hidden" name="_token" value="">
      <h3><b>TARIF KIRIMAN</b></h3>
      <div class="row" style="position:relative;">
        <label>
      <input type='hidden' name='origin_code' class='required'>
      <input type="text" name='origin_label' placeholder="Asal" class='autocomplete required' data-url='#'>
      <br>
      Asal Pengiriman</label>
        <label>
      <input type='hidden' name='dest_code' class='required'>
      <input type="text" name='dest_label' placeholder="Tujuan"  class='autocomplete required' data-url='#'>
      <br>
      Tujuan Pengiriman</label>
        <label>
          <input name="weight" type="text" placeholder="1" style="width:30px; text-align:center" class='required number'>
          <br>
          berat(Kg)</label>
      
        <div class="home-captcha">
            <div id="reCAPTCHA-2"> </div>
        </div>
        <label>
          <button class="btn red" name="check-our-tarif">check</button>

        </label>
      </div>
    <link rel='stylesheet' type='text/css' href='<?= base_url()?>assets/web/css/jquery.autocomplete.css'>
    <script src='<?= base_url()?>assets/web/js/jquery.autocomplete.min.js'></script>
    <script>
    $('.autocomplete').each(function() {
      var url = $(this).attr('data-url');
      $(this).autocomplete({
        serviceUrl: url,
        deferRequestBy: 500,
        width: 200,
        lookupFilter: function(suggestion, originalQuery, queryLowerCase) {
          var re = new RegExp('\\b' + $.Autocomplete.utils.escapeRegExChars(queryLowerCase), 'gi');
          return re.test(suggestion.value);
        },
        onSelect: function(suggestion) {
          $(this).parent().find('input[type=hidden]').val(suggestion.code);
          $(this).attr('data-origin', suggestion.value);
        }
      });
      
      $(this).blur(function() {
        $(this).val($(this).attr('data-origin'));
      });
    });
    </script>
    </form>
    <form class="network no-enter" method="post" action="#">
      <input type="hidden" name="_token" value="">

<!-- CRUD 5 -->
      <h3><b>TITIK LAYANAN</b></h3>
      <div class="row">
    <input name='latitude' type='hidden' class='required'>
    <input name='longitude' type='hidden' class='required'>
        <input name="location" type="text" id='search_location' placeholder="Find location near..." class='required'>
        <button class="btn red">Cari</i></button>
        <p>Masukan Nama Kota untuk menemukan kantor JNE.</p>
      </div>
    <script src="#"></script>
    <script>
      function map_search() {
        var input = document.getElementById('search_location');
        var autocomplete = new google.maps.places.Autocomplete(input);
        autocomplete.addListener('place_changed', function() {
          var input = $('#search_location');
          input.attr('data-origin', input.val());
          place = autocomplete.getPlace();
          if (!place.geometry) {
            input.val('');
            return;
          }
          
          $('input[name=latitude]').val(place.geometry.location.lat());
          $('input[name=longitude]').val(place.geometry.location.lng());
        });
      }
      
      $('#search_location').blur(function() {
        $(this).val($(this).attr('data-origin'));
      }).trigger('blur');
      
      google.maps.event.addDomListener(window, 'load', map_search);
      google.maps.event.addDomListener(document.getElementById('search_location'), 'keydown', function(e) { 
        if (e.keyCode == 13) { 
          e.preventDefault(); 
        }
        }); 
    </script>
    </form>
  </div>
</section>


<section id="widget">
  <div class="wrapper afterclear">
    <div class="cols w-product" type-anim="top" anim-delay="0.5">
      <h4 class="line_top">Produk</h4>
      <img src="<?= base_url()?>assets/web/img/setting-product-detail-20.jpg" alt="produk">
      <p>Dengan pengalaman selama 28 tahun, JNE melayani kebutuhan pelanggan setianya, dengan jasa pengiriman dalam dan luar negeri. </p>
    </div>
      
<!-- CRUD 4 -->
    <div class="cols w-news" type-anim="top" anim-delay="0.6" style = 'min-height: 372px;'>
      <h4 class="line_top">Publikasi</h4>
            <div class="w-list-news">
            <div class="date">14/11/2019</div>
            <h5><a href="#">JNE Manfaatkan Kekuatan Cloud untuk Mencapai Visinya dalam Ekonomi Baru</a></h5>
            <p> Jakarta, Indonesia &ndash; 14 November 2019 - Pada Oracle OpenWorld San Francisco 2019 kali ini, JNE</p>
          </div>
          <div class="w-list-news"><a href="#">JNE Cikarang Gelar Donor Darah dan Cek Kesehatan Gratis</a></div>
          <div class="w-list-news"><a href="#">DANA dan JNE Bersinergi Dukung Akselerasi Ekonomi Digital Indonesia</a></div>
    </div>
      
    
    <div class="cols w-ask" type-anim="top" anim-delay="0.8">
      <h4 class="line_top">Ask Joni</h4>
      <img src="<?= base_url()?>assets/web/img/widget-ask.png" alt="" style="margin-top:-65px; margin-bottom:-20px;">
        <div>&nbsp;
          <h5>(021) 2927 8888</h5>
        </div>
        <div>&nbsp;
          <h5>customercare@jne.co.id</h5>
        </div>
      </div>     
    </div>
  </div>
</section>


<script type="text/javascript" src="<?= base_url()?>assets/web/js/jquery.easing.min.js"></script> 
<script type="text/javascript" src="<?= base_url()?>assets/web/js/camera.min.js"></script> 
<script>
$(function(){
  var 
    headheight = $( 'header' ).outerHeight(),
    trackheight = $( '#tracking' ).outerHeight(),
    banner_height= $(window).height() - (headheight+trackheight);
  if($(window).width() >=768 ) {
    jQuery('#camera_wrap_2').camera({     
      loader: 'none',
      pagination: true,
      height: banner_height+"px",
      thumbnails: false,
      playPause: false,
    });
  } else {
    jQuery('#camera_wrap_2').camera({     
      loader: 'none',
      pagination: true,
      thumbnails: false,
      playPause: false,
      onEndTransition : function(){
        $('.camera_wrap').css({height: $('.cameraSlide <?= base_url()?>assets/web/img').height()+'px !impoortant'});
      }
    });
  }

});
$(document).keypress(function(e) {
    if(e.which == 13) {
    }
});
</script>
</div>


<footer>
  <div class="top">
    <div class="wrapper afterclear">
      <div class="left" type-anim="top" anim-delay="1.2">
        <div class="logo"><a href="#"><img src="<?= base_url()?>assets/web/img/logo-footer.png" width="136" height="139" alt="" /></a></div>
        <p><strong>KANTOR PUSAT</strong><br />
         <p>Jl. Tomang Raya No. 11<br />
              Jakarta Barat 11440<br />
              Indonesia</p>

              <p>Contact center. (021) 2927 8888<br />
              Office. (62-21) 566 5262<br />
              Fax. (62-21) 567 1413<br />
              Email. customercare@jne.co.id</p>
        </p>
      </div>

      <div class="right">
        <nav type-anim="top" anim-delay="1.3"> <a href="#" class="parent line_top">Perusahaan</a>
          <ul>       
            <li><a href="#">Profil Perusahaan</a></li>         
            <li><a href="#">Penghargaan</a></li>         
            <li><a href="#">CSR</a></li>
          </ul>
        </nav>
        
        <nav type-anim="top" anim-delay="1.4"> <a href="#" class="parent line_top">Produk &amp; Layanan</a>
          <ul>
            <li><a href="#"> JNE Express</a></li>
            <li><a href="#"> JNE Logistic</a></li>
            <li><a href="#"> JNE Freight</a></li>
          </ul>
        </nav>
               
        <nav type-anim="top" anim-delay="1.5"> <a href="#" class="parent line_top">Solusi Bisnis</a>
          <ul>             
            <li><a href="#">Kemitraan</a></li>
            <li><a href="#">Corporate</a></li>
            <li><a href="#">Tentang Indonesia</a></li>   
          </ul>
        </nav>

        <nav type-anim="top" anim-delay="1.6"> <a href="#" class="parent line_top">Link Terkait</a>
          <ul>
            <li> <a href="#">Trace &amp; Tracking</a></li>
            <li><a href="#">Shipping Rates</a></li>
            <li><a href="#"> Our Networks</a></li>
            <li><a href="#">Berita</a></li>
          </ul>
        </nav>
      </div>


    </div>
  </div>
  
  <div class="bottom">
    <div class="wrapper afterclear">
      <p class="left" type-anim="top" anim-delay="1.2">
        <a href = '#'>Kebijakan Privasi dan Pengamanan</a> <br/>
        Copyright &copy; 2015 JNE. All Rights Reserved.
      </p>
      <div class="phone" type-anim="top" anim-delay="1.3"><a href="#">Customer Care  <strong>(021) 2927 8888</strong></a> <a href="#">Customer Care <strong>customercare@jne.co.id</strong></a></div>
    </div>
  </div>
</footer>
</body>
</htmL>
