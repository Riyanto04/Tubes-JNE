<html>
<head>
<style>
    table,tr,td{
        border : 1px solid;
        border-colapse:colapse;
    }
</style>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

    <div class="container mt-5">
        <h2>Data Tracking barang</h2>
        <div class="row">
            <div class="col-md-12">
            
                <div align="right" style="margin-right: 4%;margin-bottom: 2%">
                    <button class="btn btn-sm btn-primary action" onclick="location.href='<?php echo site_url('/dashboard'); ?>'">Create</button>
                </div>
                <table class="table">
                    <tr>
                        <td>Nama Pengirim</td>
                        <td>kode tracking</td>
                        <td>Alamat Tujuan</td>
                        <td>Nama Penerima</td>
                    </tr>
                    <?php
                    foreach ($Data){
                    ?>
                    <tr>
                        <td><?=$a['nm_pengirim']?></td>
                        <td><?=$a['kode_tracking']?></td>
                        <td><?=$a['alamat_tujuan']?></td>
                        <td><?=$a['nm_penerima']?></td>
                        <td>
                            <button class="btn btn-sm btn-danger action" data-toggle="modal" data-target="<?php echo $a['kode_tracking']; ?>">delete</button>
                            <button class="btn-sm btn btn-primary action" data-toggle="modal" data-target="<?php echo $a['kode_tracking']; ?>">edit</button>
                            <?php include "formeditdashboard.php"; ?>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
        
            </div>

    </div>
</div>
</body>
</html>
