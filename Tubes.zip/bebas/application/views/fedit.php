<div class="modal fade" id="modal-update<?php echo $a['id_lokasi']; ?>">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title">Update Lokasi - <?php echo $a['id_lokasi']; ?></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <div class="modal-body">
        <!-- Form modal untuk menginputkan data buku -->
            <form action="<?php echo site_url('home/update'); ?>" method="POST" enctype="multipart/form-data">

            <div class="form-group">
                <label for="id_lokasi">ID Lokasi</label>
                <input class="form-control" type="text" name="id_lokasi" value="<?php echo $a['id_lokasi'];?>" readonly/>
            </div>

            <div class="form-group">
                <label for="nama_jne">Nama Lokasi JNE</label>
                <input class="form-control" type="text" name="nama_jne" value="<?php echo $a['nama_jne'];?>" placeholder="Nama Lokasi JNE" required/>
            </div>

            <div class="form-group">
                <label for="alamat_jne">Alamat JNE</label>
                <input class="form-control" type="text" name="alamat_jne" value="<?php echo $a['alamat_jne'];?>" placeholder="Alamat JNE" required/>
            </div>


                <input type="submit" class="btn btn-primary btn-block" name="update" value="update" />

        </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer"></div>

    </div>
  </div>
</div>
