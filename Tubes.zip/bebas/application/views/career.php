<!DOCTYPE html>
<html>
<head>
	<title>Karir</title>
</head>
<body>
	<form action="<?= base_url()?>index.php/admin/input_tracking" method="POST">
		<center>
		<h2>career</h2>
		<br><input type="text" name="id_career" placeholder="Id_career"></br>
		<br><input type="text" name="jd_career" placeholder="Jd_career"></br>
		<br><input type="text" name="deskripsi" placeholder="Deskripsi"></br>
		<br><input type="submit" name="submit"></br>
		</center>
	</form>
</body>
</html>