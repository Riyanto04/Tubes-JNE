<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register Admin</title>
    
    <link rel="stylesheet" href="<?php echo base_url('assets/template/bootstrap/css/bootstrap.min.css')?>">
    <script src="<?php echo base_url('assets/template/plugins/jQuery/jQuery-2.1.4.min.js')?>"></script>
    <script src="<?php echo base_url('assets/template/bootstrap/js/bootstrap.min.js')?>"></script>
</head>
<body>

<div class="container mt-5">
    <h2>Input Data Lokasi JNE</h2>
    <div class="row">
        <div class="col-md-12">

        <form action="<?php echo site_url('home/addlokasi'); ?>" method="POST" enctype="multipart/form-data">

            <div class="form-group">
                <label for="id_lokasi">ID Lokasi</label>
                <input class="form-control" type="text" name="id_lokasi" placeholder="ID Lokasi" required/>
            </div>

            <div class="form-group">
                <label for="nama_jne">Nama Lokasi JNE</label>
                <input class="form-control" type="text" name="nama_jne" placeholder="Nama Lokasi JNE" required/>
            </div>

            <div class="form-group">
                <label for="alamat_jne">Alamat JNE</label>
                <input class="form-control" type="number" name="alamat_jne" placeholder="Alamat JNE" required/>
            </div>

            <input type="submit" class="btn btn-primary btn-block" name="daftar" value="Create" required/>

        </form>
            
        </div>

    </div>
</div>

</body>
</html>